package org.signify.OnlineContactManagementSystem;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OnlineManagementSystemApplication {

	public static void main(String[] args) {

		SpringApplication.run(OnlineManagementSystemApplication.class, args);
	}

}
